echo "Enter A Number :" 
read n
r=n 
s=0 
rem=0 
while [ $n -gt 0 ]
do 
rem=$(($n%10))
s=$(($s+$rem*$rem*$rem)) 
n=$(($n/10)) 
done 
if [ $r == $s ]; 
then 
echo "The Number is Avogadro" 
else 
echo "The Number is Not Avogadro" 
fi
