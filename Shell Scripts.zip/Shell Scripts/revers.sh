
# Script to reverse given no
#
# Algo:
#       1) Input number n
#       2) Set rev=0, sd=0
#     3) Find single digit in sd as n % 10 it will give (left most digit)
#       4) Construct reverse no as rev * 10 + sd
#       5) Decrement n by 1
#       6) Is n is greater than zero, if yes goto step 3, otherwise next step
#       7) Print rev
#
echo "Enter a number "
read n

 
rev=0
sd=0
 
while [ $n -gt 0 ]
do
    sd=`expr $n % 10`
    rev=`expr $rev \* 10  + $sd`
    n=`expr $n / 10`
done
    echo  "Reverse number is $rev"
 
#
