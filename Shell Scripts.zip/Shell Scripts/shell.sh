#script to make and edit a file easily
chmod +x shell.sh
echo "enter a file name"
read fname
touch $fname

chmod +x $fname
echo " '$fname' file created successfully "
echo " And $fname file located in:" 
pwd
echo "It has opened in editor." 
gedit $fname
echo " $fname file updated Successfully.Now you can run it with ./$fname "


