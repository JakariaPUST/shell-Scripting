
echo "Set timer time: "
read input
echo "Timer running"
for (( i=$input; i>0; i--)); do

  sleep 1 &
  echo "  $i "
  wait
done
echo "Timer stoped"
