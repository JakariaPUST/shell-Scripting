echo "previous file elements: "
cat filename.txt
echo
output=sortedfilename.txt
sort filename.txt > $output
echo "sorted file names in a different file called' $output ':"
cat $output



